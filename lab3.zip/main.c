#define _POSIX_C_SOURCE 199309L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "quicksort.h"

#define N 10000000

static void fill_random(int *a, size_t n){
	srand((unsigned)time(NULL));
	for(size_t i=0; i<n; ++i)
		a[i] = rand();
}

static int cmp_ints(const void *x, const void *y){
	int a = *(const int *)x;
	int b = *(const int *)y;
	return (a>b) - (a<b);
}


static int is_sorted(const int *a, size_t n){
	for(size_t i=1; i<n; ++i)
		if(a[i]<a[i-1])
			return 0;
	return 1;
}


static double now_ms(void){
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}


int main(void){
	int *a = malloc(N * sizeof(int));
	int *b = malloc(N * sizeof(int));

	if(!a || !b){
		fprintf(stderr, "Memory allocation failed\n");
		return 1;
	}

	fill_random(a,N);
	memcpy(b, a, N*sizeof(int));

	double t0 = now_ms();
	quicksort(a, N);
	double t1 = now_ms();

	double t2 = now_ms();
	qsort(b, N, sizeof(int), cmp_ints);
	double t3 = now_ms();
	
	printf("My quicksort: %.3f ms\n", t1-t0);
	printf("qsort: %.3f ms\n", t3-t2);
	printf("Correctness: %s\n", is_sorted(a,N) ? "PASS" : "FAIL");

	free(a);
	free(b);
	return 0;
}
	










	
























#ifndef QUICKSORT_H
#define QUICKSORT_H

#include <stddef.h>

void quicksort(int *a, size_t n);

#endif

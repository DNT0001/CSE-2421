#include "quicksort.h"

static inline void swap(int *x, int *y){
	int t = *x;
	*x = *y;
	*y = t;
}

static int partition(int *a, int low, int high){
	int pivot = a[low + (high - low)/2];
	int i = low - 1;
	int j = high + 1;

	while(1){
		do{i++;} while(a[i] < pivot);
		do{j--;} while(a[j] > pivot);

		if(i >= j)
			return j;

		swap(&a[i], &a[j]);
	}
}


static void quicksort_rec(int *a, int low, int high){
	if(low < high){
		int p = partition(a, low, high);
		quicksort_rec(a, low, p);
		quicksort_rec(a, p+1, high);
	}
}



void quicksort(int *a, size_t n){
	if(n>1)
		quicksort_rec(a,0, (int)n-1);
}












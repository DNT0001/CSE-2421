#include <stdio.h>

int main(void){
	printf("Hello. My name is Debapratim Talukder.\n");
	return 0;
}
